var num1  = window.prompt("Digite um número: ");
var num2 = window.prompt("Digite mais um número: ");
window.alert("Resultado: " + (parseInt(num1)+parseInt(num2)));
//parseInt converte um texto em número inteiro

//calcular a média aritimética de 4 notas
var n1=window.prompt("Informe a primeira nota:");
var n2=window.prompt("Informe a segunda nota:");
var n3=window.prompt("Informe a terceira nota:");
var n4=window.prompt("Informe a quarta nota:");
//método para cálcular a média

var media = (parseInt(n1)+parseInt(n2)+parseInt(n3)+parseInt(n4))/4;
window.alert("A média final é: " + media);