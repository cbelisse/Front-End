<?php
//Comentário linha
/*Comentário multiplas
linhas 
*/
$nome="Marcos";
$idade=23;
$v1=10;
$v2=20;
//$soma=$v1+$v2;
echo "Olá Mundo !!! (Hello World !!!)<br>";
print("Meu nome é: " .$nome);
echo"<br>";
echo "Eu tenho, " .$idade;
echo"<br>";
echo"<div style='background-color:green;'>Soma dos valores:".($v1+$v2)."</div>";
?>