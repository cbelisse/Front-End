<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 1 - PHP</title>
</head>
<body>
    <h1>Olá Mundo !!! </h1>
    <?php
    echo "<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aliquid culpa autem impedit? Blanditiis nulla culpa itaque autem, enim quidem voluptatum error hic sequi optio ipsa commodi harum accusantium dolore! Totam.</p>";

    ?>
    
</body>
</html>